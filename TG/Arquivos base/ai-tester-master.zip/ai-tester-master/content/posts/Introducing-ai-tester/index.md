---
title: "Introducing AI Tester"
cover: "/photos/ai-tester.png"
category: "ai-tester"
tags:

    - AI-tester
    - AI
    - testing
    - machine-learning

date: "08/01/2017"
---
# The initiative

As a developer, we want to focus on the development effort for the features.  If AI can read the code we write, and analyze the code, and write the tests for the code, it will be amazing!

So this project is to see how we can leverage the Machine Learning techniques, to analyze the code we write, and automate the unit and functional automation tests.
